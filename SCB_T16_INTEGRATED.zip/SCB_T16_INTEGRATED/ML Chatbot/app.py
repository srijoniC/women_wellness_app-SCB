from flask import Flask, render_template, request
#import chatbotscb
#from chatbotscb import patientInfo

app = Flask(__name__)



@app.route("/")
def home():
    print("inside home")
    return render_template("index.html")


@app.route("/get")
def get_bot_response():
    #chatbotscb.patientInfo()
    userText = request.args.get('msg')
    
    return str()


if __name__ == "__main__":
    app.run()